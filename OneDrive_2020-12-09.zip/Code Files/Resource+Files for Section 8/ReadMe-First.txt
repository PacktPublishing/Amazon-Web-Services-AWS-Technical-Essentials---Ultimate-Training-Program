Important Note - The script will only work with the Linux2 AMI. (The previous AMI has been moved to the Community AMI Section). For example, the Linux 2 AMI - Amazon Linux 2 AMI (HVM), SSD Volume Type - ami-0a669382ea0feb73a

